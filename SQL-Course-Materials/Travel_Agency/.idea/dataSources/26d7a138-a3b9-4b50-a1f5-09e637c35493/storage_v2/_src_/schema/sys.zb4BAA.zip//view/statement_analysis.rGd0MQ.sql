create definer = `mariadb.sys`@localhost view statement_analysis as
select `sys`.`format_statement`(`performance_schema`.`events_statements_summary_by_digest`.`DIGEST_TEXT`)      AS `query`,
       `performance_schema`.`events_statements_summary_by_digest`.`SCHEMA_NAME`                                AS `db`,
       if(`performance_schema`.`events_statements_summary_by_digest`.`SUM_NO_GOOD_INDEX_USED` > 0 or
          `performance_schema`.`events_statements_summary_by_digest`.`SUM_NO_INDEX_USED` > 0, '*',
          '')                                                                                                  AS `full_scan`,
       `performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`                                 AS `exec_count`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_ERRORS`                                 AS `err_count`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_WARNINGS`                               AS `warn_count`,
       `sys`.`format_time`(`performance_schema`.`events_statements_summary_by_digest`.`SUM_TIMER_WAIT`)        AS `total_latency`,
       `sys`.`format_time`(`performance_schema`.`events_statements_summary_by_digest`.`MAX_TIMER_WAIT`)        AS `max_latency`,
       `sys`.`format_time`(`performance_schema`.`events_statements_summary_by_digest`.`AVG_TIMER_WAIT`)        AS `avg_latency`,
       `sys`.`format_time`(`performance_schema`.`events_statements_summary_by_digest`.`SUM_LOCK_TIME`)         AS `lock_latency`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_SENT`                              AS `rows_sent`,
       round(ifnull(`performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_SENT` /
                    nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`, 0), 0),
             0)                                                                                                AS `rows_sent_avg`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_EXAMINED`                          AS `rows_examined`,
       round(ifnull(`performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_EXAMINED` /
                    nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`, 0), 0),
             0)                                                                                                AS `rows_examined_avg`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_AFFECTED`                          AS `rows_affected`,
       round(ifnull(`performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_AFFECTED` /
                    nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`, 0), 0),
             0)                                                                                                AS `rows_affected_avg`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_CREATED_TMP_TABLES`                     AS `tmp_tables`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_CREATED_TMP_DISK_TABLES`                AS `tmp_disk_tables`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_ROWS`                              AS `rows_sorted`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_MERGE_PASSES`                      AS `sort_merge_passes`,
       `performance_schema`.`events_statements_summary_by_digest`.`DIGEST`                                     AS `digest`,
       `performance_schema`.`events_statements_summary_by_digest`.`FIRST_SEEN`                                 AS `first_seen`,
       `performance_schema`.`events_statements_summary_by_digest`.`LAST_SEEN`                                  AS `last_seen`
from `performance_schema`.`events_statements_summary_by_digest`
order by `performance_schema`.`events_statements_summary_by_digest`.`SUM_TIMER_WAIT` desc;

-- comment on column statement_analysis.db not supported: Database name. Records are summarised together with DIGEST.

-- comment on column statement_analysis.exec_count not supported: Number of summarized events

-- comment on column statement_analysis.err_count not supported: Sum of the ERRORS column in the events_statements_current table.

-- comment on column statement_analysis.warn_count not supported: Sum of the WARNINGS column in the events_statements_current table.

-- comment on column statement_analysis.rows_sent not supported: Sum of the ROWS_SENT column in the events_statements_current table.

-- comment on column statement_analysis.rows_examined not supported: Sum of the ROWS_EXAMINED column in the events_statements_current table.

-- comment on column statement_analysis.rows_affected not supported: Sum of the ROWS_AFFECTED column in the events_statements_current table.

-- comment on column statement_analysis.tmp_tables not supported: Sum of the CREATED_TMP_TABLES column in the events_statements_current table.

-- comment on column statement_analysis.tmp_disk_tables not supported: Sum of the CREATED_TMP_DISK_TABLES column in the events_statements_current table.

-- comment on column statement_analysis.rows_sorted not supported: Sum of the SORT_ROWS column in the events_statements_current table.

-- comment on column statement_analysis.sort_merge_passes not supported: Sum of the SORT_MERGE_PASSES column in the events_statements_current table.

-- comment on column statement_analysis.digest not supported: Performance Schema digest. Records are summarised together with SCHEMA NAME.

-- comment on column statement_analysis.first_seen not supported: Time at which the digest was first seen.

-- comment on column statement_analysis.last_seen not supported: Time at which the digest was most recently seen.

